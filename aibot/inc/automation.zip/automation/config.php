<?php

return [
    'id' => 'automation',
    'name' => 'Automation',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'fas fa-sync',
    'color' => '',
    'menu' => [
        'tab' => 3,
        'position' => 700,
        'name' => 'Automation'
    ]
	
];