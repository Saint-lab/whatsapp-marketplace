<?php

return [
    'id' => 'dfy',
    'name' => 'DFY',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'fa fa-bookmark',
    'color' => '#b0d685',
    'menu' => [
        'tab' => 3,
        'position' => 200,
        'name' => 'DFY'
    ]
	
];