<?php

return [
    'id' => 'leads',
    'name' => 'Leads',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => 'Your Product leads',
    'icon' => 'fa fa-book',
    'color' => '#648003',
    'menu' => [
        'tab' => 3,
        'position' => 400,
        'name' => 'Leads'
    ]
	
];