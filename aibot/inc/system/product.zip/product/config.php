<?php

return [
    'id' => 'product',
    'name' => 'Product',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'fa fa-shopping-basket',
    'color' => 'blue',
    'menu' => [
        'tab' => 2,
        'position' => 400,
        'name' => 'Product'
    ]
	
];