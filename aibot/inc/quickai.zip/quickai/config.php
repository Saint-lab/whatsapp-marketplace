<?php

return [
    'id' => 'reseller',
    'name' => 'Reseller',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'fas fa-sync',
    'color' => '',
    'menu' => [
        'tab' => 4,
        'position' => 900,
        'name' => 'Reseller'
    ]
	
];